import json
import pickle
import subprocess
import random

def get_predicated_value(married,age,number_of_missed_payments):
    predicted_value = random.uniform(0.5, 1);
    
    return predicted_value
    
def close(session_attributes, fulfillment_state, message):
    """
    Defines a close slot type response.
    """
    response = {
        "sessionAttributes": session_attributes,
        "dialogAction": {
            "type": "Close",
            "fulfillmentState": fulfillment_state,
            "message": message,
        },
    }
    return response
    
def lambda_handler(event, context):
    married=0
    isMarried=str(event['currentIntent']['slots']['isMarried'])
    if(isMarried == "Yes"):
        married = 1
    age=int(event['currentIntent']['slots']['age'])
    print(age)
    numberOfPaymentsMissed=int(event['currentIntent']['slots']['paymentsMissed'])
    print(numberOfPaymentsMissed)
    predicted_value=get_predicated_value(married,age,numberOfPaymentsMissed)
    return close(
        event["sessionAttributes"],
        "Fulfilled",
        {
            "contentType": "PlainText",
            "content": """The information you provided are the following.
                          Married:{}.
                          Age:{}.
                          Number Of Missed Payments in the last 6 months:{}.
                          Based on the above the probability of you missing payment next month is {}""".format(
                          isMarried, age,numberOfPaymentsMissed,predicted_value),
        },
    )
    
    
